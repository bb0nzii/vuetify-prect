<template>
<v-main>
    <router-view></router-view>
</v-main>
</template>
