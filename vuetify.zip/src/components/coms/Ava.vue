<template>
    <v-container>
        <v-row>
            <v-col cols="12" md="4">
                <v-card class="mx-auto" max-width="" rounded="0">                  
                    <v-img height="100%" src="http://cdn.vuetifyjs.com/images/cards/server-room.jpg" cover></v-img>
                    
                    <v-avatar color="grey" rounded="0" size="150">
                        <v-img src="https://cdn.vuetifyjs.com/images/profiles/marcus.jpg" cover></v-img>
                    </v-avatar>

                    <v-list-item class="text-white"
                    subtitle="Network Engineer"
                    title="Marcus Obrien">
                    </v-list-item>      
                </v-card>
            </v-col>
            <v-col cols="12" md="4">
            
            </v-col>
            <v-col cols="12" md="4">
            
            </v-col>
        </v-row>
    </v-container>
</template>