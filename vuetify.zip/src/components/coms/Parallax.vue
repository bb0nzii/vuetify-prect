<template>
    <v-parallax src="https://cdn.vuetifyjs.com/images/parallax/material.jpg"></v-parallax>
    <h1 class="text-center my-5">글씨가 들어간 Parallax</h1>
    <v-parallax src="http://cdn.vuetifyjs.com/images/backgrounds/vbanner.jpg">
        <div class="d-flex flex-column fill-height justify-center align-center text-white">
            <h1 class="text-h4 font-weight-bold mb-4">
                To. 윤지
            </h1>
            <h2 class="subheading font-weight-thin">
                잘 복붙하고 계심?
            </h2>
        </div>
    </v-parallax>
</template>