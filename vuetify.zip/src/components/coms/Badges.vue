<template>
  <v-container>
    <v-row>
        <v-col cols="12" md="4">

        </v-col>
        <v-col cols="12" md="4">
            
        </v-col>
        <v-col cols="12" md="4">
            
        </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {

}
</script>

<style>

</style>