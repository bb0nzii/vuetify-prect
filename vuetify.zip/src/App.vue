<script setup>
import Header from './include/Header.vue';
import Footer from './include/Footer.vue';
</script>

<template>

<v-app>
    <Header/>    
</v-app>

<Footer/>

</template>

<script>
export default {
  name: 'App',
}
</script>